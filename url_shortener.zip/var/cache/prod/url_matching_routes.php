<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/([^/]++)(*:16)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        16 => [
            [['_route' => 'redirect_to_original', '_controller' => 'App\\Controller\\UrlController::redirectToOriginalUrl'], ['urlCorta'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
